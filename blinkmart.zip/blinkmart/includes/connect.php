<?php
$con=mysqli_connect('localhost','root','','blinkmart');
if(!$con)
    echo "error Connecting to Database";

?>